// SDK 55+ removed `expo/AppEntry.js`, so the app registers itself here.
import { registerRootComponent } from "expo";
import App from "./App";

// Wraps App with the Expo Go / native-build setup and calls AppRegistry.registerComponent("main", ...).
registerRootComponent(App);
